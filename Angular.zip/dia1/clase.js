var Persona = /** @class */ (function () {
    function Persona(var1, var2) {
        this.nombre = var1;
        this.apellido = var2;
    }
    Persona.prototype.setNombre = function (nombre1) {
        this.nombre = nombre1;
    };
    Persona.prototype.getNombre = function () {
        return this.nombre;
    };
    return Persona;
}());
var persona1 = new Persona('Santiago', 'Zamora');
console.log(persona1.nombre);
persona1.setNombre('Stalin');
console.log(persona1.nombre);
function mostrarTexto1(error, seg) {
    console.log('ocurrió un error: ' + error + ' en: ' + seg + ' segundos.');
}
mostrarTexto1('capa8', 5);
function mostrarTexto2(error, seg) {
    console.log("ocurri\u00F3 un error:  " + error + "  en: " + seg + "  segundos.");
}
mostrarTexto2('capa8', 6);
