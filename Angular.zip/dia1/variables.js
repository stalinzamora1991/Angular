var hora;
var hora1;
var activo = true;
var texto = 'hola';
var texto2 = ['A', 'B'];
var desconocido1 = 2;
desconocido1 = 'texto1';
desconocido1 = true;
var persona = {
    nombre: 'Santiago',
    apellido: 'Zamora'
};
console.log(persona.nombre);
