var hora: number;
var hora1: 'cadena';
var activo: boolean = true;
var texto: string='hola';
var texto2: string[] = ['A','B'];

var desconocido1: any = 2;
desconocido1= 'texto1';
desconocido1 = true;

interface Persona2 {
    nombre: string;
    apellido: string;
}
var persona: Persona2 = {
    nombre: 'Santiago',
    apellido: 'Zamora'
}
console.log(persona.nombre);