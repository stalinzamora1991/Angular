var numero: number[] = [];
var number2: Array<number> = [];
numero.push(2,4,6,8);
var nombres: string[] = ['stalin1','stalin2'];

//map :: crea un arreglo con el resultado de la funcion
var cuadrado = numero.map((numero)=> Math.pow(numero,2));
console.log(cuadrado);

//filter:: nos permite filtrar los elementos que deseemos
var numero3 = [2,3,5,76,4,23,7];
var filtro1 = numero3.filter(number => number>3);
console.log(filtro1);

//foreach :: enlista los elementos de mi arreglo
var num1 = [1,2,3,4,5,6];
num1.forEach(function(value) {console.log(value); });

//find:: devuelve el primero elemento que cumpla con la condicion
var arreglo1=[2,6,4,8];
var encuentra = arreglo1.find((element)=>(element>3));
console.log('resultado: ' + encuentra);