//funciones con parametros y sin parametros
function suma(a, b) {
    return a + b;
}
var x = suma(3, 5);
console.log(x);
function mostrarCadena(texto) {
    if (texto === void 0) { texto = 'hola'; }
    if (texto) {
        console.log('cadena llena');
    }
    else {
        console.log('cadena vacía');
    }
}
mostrarCadena();
//funcion fecha
var nombre = function getNombre() {
    return 'Stalin Zamora';
};
console.log(nombre());
var nombre2 = function () { return 'Santiago Zamora'; };
console.log(nombre2());
var resultado = function (valor1, valor2) { return (valor1 + valor2); };
console.log(resultado(1, 4));
var mostrarItem = function mostraarDatos(id) {
    return { id: id,
        nombre: 'Santiago' };
};
console.log(mostrarItem(1));
var mostraritem2 = function (id) { return ({ id: id, nombre: 'Santiago2' }); };
console.log(mostraritem2(3));
