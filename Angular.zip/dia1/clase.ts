class Persona{
    public nombre;
    public apellido;

    constructor(var1: string, var2:string){
        this.nombre = var1;
        this.apellido = var2;
    }
setNombre(nombre1: string){
this.nombre = nombre1;
}    

getNombre(){
    return this.nombre;
}
}
var persona1 = new Persona('Santiago','Zamora');
console.log(persona1.nombre);
persona1.setNombre('Stalin');
console.log(persona1.nombre);

function mostrarTexto1(error: string, seg: number){
    console.log('ocurrió un error: '+ error + ' en: ' + seg + ' segundos.');
}
mostrarTexto1('capa8',5);

function mostrarTexto2(error: string, seg: number){
    console.log(`ocurrió un error:  ${error}  en: ${seg}  segundos.`);
}
mostrarTexto2('capa8',6);