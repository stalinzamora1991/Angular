export class Customer {
id: number;
firstname: string;
lastname: string;
age: number;
}
