const db = require('../config/db.config.js');
const Customer = db.customers;

// Crear un cliente
exports.create = (req, res) => {	
	// Save to MySQL database
	let customer = req.body;
	Customer.create(customer).then(result => {		
		// Envía cliente creado a customers
		res.json(result);
	});
};
 
// Encontrar todos los usuarios
exports.findAll = (req, res) => {
	Customer.findAll().then(customers => {
	  // Envìa todos los clientes a customers
	  res.json(customers);
	});
};

// Encuentra un cliente por Id
exports.findById = (req, res) => {	
	Customer.findById(req.params.customerId).then(customer => {
		res.json(customer);
	})
};
 
// Actualiza un cliente
exports.update = (req, res) => {
	let customer = req.body;
	let id = req.body.id;
	Customer.update(customer, 
					 { where: {id: id} }
				   ).then(() => {
						 res.status(200).json({msg:"Actualizado correctamente el cliente con id = " + id});
				   });	
};
 
// Elimina un cliente por ID
exports.delete = (req, res) => {
	const id = req.params.customerId;
	Customer.destroy({
	  where: { id: id }
	}).then(() => {
	  res.status(200).json({msg:'Eliminado correctamente un cliente con id = ' + id});
	});
};