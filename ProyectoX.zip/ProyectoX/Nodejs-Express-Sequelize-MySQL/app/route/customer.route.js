module.exports = function(app) {
 
    const customers = require('../controller/customer.controller.js');
 
    // Crea un nuevo cliente
    app.post('/api/customers', customers.create);
 
    // Muestra todos los clientes
    app.get('/api/customers', customers.findAll);
 
    // Muestra un cliente por ID
    app.get('/api/customers/:customerId', customers.findById);
 
    // Actualiza un cliente por id
    app.put('/api/customers', customers.update);
 
    // Elimina un cliente por id
    app.delete('/api/customers/:customerId', customers.delete);
}