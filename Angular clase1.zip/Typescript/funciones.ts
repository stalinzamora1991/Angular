function suma (a: number, b: number){
    return a+b;
};
var x= suma(2,4);
console.log(x);

function mostrar(texto: string='hola'){
    if (texto){
        console.log('Si llego la cadena: '+ texto);
    }
    else{
        console.log('NO llego la cadena');
    }
}
var y= mostrar();

function mostrarTexto(error: string, seg: string){
 console.log('Error:'+error +'. En'+seg +' segundos');
}
mostrarTexto('capa 8','10');
function mostrarTexto2(error: string, seg: string){
    console.log(`Error: ${error}. En ${seg} segundos`);
   }
mostrarTexto2('capa 8','12');