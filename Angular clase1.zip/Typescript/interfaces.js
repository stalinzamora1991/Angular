var per1 = {
    nombre: 'Santiago',
    apellido: 'Zamora'
};
console.log(per1);
var Cliente = /** @class */ (function () {
    function Cliente(nom, ape, iden) {
        this.nombre = nom;
        this.apellido = ape;
        this.identificacion = iden;
    }
    return Cliente;
}());
var nuevoCliente = new Cliente('Stalin', 'Zamora', '09304876544');
console.log(nuevoCliente);
