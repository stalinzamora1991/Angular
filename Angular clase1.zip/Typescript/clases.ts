class Personas{
    public nombre;
    public apellido;

constructor(var1: string, var2: string){
this.nombre = var1;
this.apellido=var2;
}
getNombre(){
    return this.nombre}

setNombre(nombrex: string){
this.nombre = nombrex; }
}
var persona1 = new Personas('Santiago','Zamora');
console.log(persona1.nombre);

persona1.setNombre('Stalin');
console.log(persona1.nombre);
