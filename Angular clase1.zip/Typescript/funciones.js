function suma(a, b) {
    return a + b;
}
;
var x = suma(2, 4);
console.log(x);
function mostrar(texto) {
    if (texto === void 0) { texto = 'hola'; }
    if (texto) {
        console.log('Si llego la cadena: ' + texto);
    }
    else {
        console.log('NO llego la cadena');
    }
}
var y = mostrar();
function mostrarTexto(error, seg) {
    console.log('Error:' + error + '. En' + seg + ' segundos');
}
mostrarTexto('capa 8', '10');
function mostrarTexto2(error, seg) {
    console.log("Error: " + error + ". En " + seg + " segundos");
}
mostrarTexto2('capa 8', '12');
