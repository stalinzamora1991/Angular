import { Component } from '@angular/core';
import { Personas } from './interfaces/personas';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  mensaje='mensaje de prueba';
  title = 'proyecto1';
  nombres = 'Santiago Zamora';
  titulo= 'Angular 7';
persona: Personas ={
  nombres: 'Santiago',
  apellidos: 'Zamora'
}
textomin='clase angular';
textomay='CLASE ANGULAR';
titulo2 ='las clases de angular';
valor = 3.1416;
fecha = Date.now();
obtenertitulo(){
  return this.title;
}
boton1='Boton Angular';
nuevoCorreo='sza';


cambiartexto(){
  this.boton1='Boton salir';
}
}
