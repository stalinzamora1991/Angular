var numero: number;
var nombre: string;
var activo: boolean;
var texto1: string= 'hola';
var numeros: string[]=['A','B'];

let desconocido: any=2;
desconocido='Santiago';
desconocido=true;

interface Persona {
    nombre:string;
    apellido: string;
}
var persona1: Persona = {
    nombre:'Santiago',
    apellido: 'Zamora'
}
