setTimeout(function () {
    console.log('Saludos Curso Angular');
}, 0);
setTimeout(function () {
    return console.log('Saludos Curso Angular 2');
}, 0);
var nombre1 = function getNombre() {
    return 'Santiago Zamora';
};
console.log(nombre1());
var nombre2 = function () { return 'Santiago Zamora'; };
console.log(nombre2());
var resultado = function sumar(valor1, valor2) {
    return valor1 + valor2;
};
var resultado = function (valor1, valor2) { return (valor1 + valor2); };
console.log(resultado(2, 5));
