var numeros: number[] = [];
var numeros2: Array<number> = [];
numeros.push(10,20,30,40);
var nombres: string[] = ['Santiago','Zamora'];

// funcion map
var cuadrado = numeros.map((numeros) => Math.pow(numeros,2));
console.log(cuadrado);

//filter
var numero3 = [1,5,23,4,12,5,34];
var x = numero3.filter(a => a > 10);
console.log(x);

//foreach
var numero4= [7,8,9];
numero4.forEach( function(valuex1){
    console.log(valuex1);
})

//reduce
const suma = [10,20,30].reduce((a,b) => a+b);
console.log('la suma es: '+ suma);

//find
var arreglo1 = [2,4,1,8,10];
var encuentra = arreglo1.find(function(element){ return element>4; });
console.log('el numero filtrado es: ' + encuentra);