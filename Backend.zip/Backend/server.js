var express = require('express');
var app = express();
var bodyParser = require('body-parser');
app.use(bodyParser.json())

const cors = require('cors')
const corsOptions = {
  origin: 'http://localhost:4200',
  optionsSuccessStatus: 200
}

app.use(cors(corsOptions))

const db = require('./app/config/db.config.js');
  
// force: true :: eliminará la tabla si esta ya existe
db.sequelize.sync({force: true}).then(() => {
  console.log('Se elimina y crear la tabla si { force: true }');
  initial();
});

require('./app/route/customer.route.js')(app);
 
// Crea un servidor
var server = app.listen(8080, function () {
  let host = server.address().address
  let port = server.address().port

  console.log("App listening at http://%s:%s", host, port);
})

function initial(){

  let customers = [   
    { id: 1,firstname: "Santiago",lastname: "Zamora",age: 28},
    { id: 2,firstname: "Zoila",lastname: "Quinonez",age: 33},
    { id: 3,firstname: "Juan",lastname: "Torres",age: 28},
    { id: 4,firstname: "Paul",lastname: "Méndez",age: 33},
    { id: 5,firstname: "Isabel",lastname: "Avilés",age: 33},
    { id: 6,firstname: "Diego",lastname: "Méndez",age: 28},
    { id: 7,firstname: "Milton",lastname: "Cabrera",age: 28},
    { id: 8,firstname: "Ricardo",lastname: "Estrada",age: 28},
  ]

  // Inicia Datos -> Graba en Mysql
  const Customer = db.customers;
  for (let i = 0; i < customers.length; i++) { 
    Customer.create(customers[i]);  
  }
}