import { Component, OnInit } from '@angular/core';
import { Customer } from '../Modelos/customer';
import { CustomerService } from '../Servicios/customer.service';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.scss']
})
export class CustomerComponent implements OnInit {
  customers: Customer[];

  constructor(private customerService: CustomerService) {}

  ngOnInit(): void {
     this.getCustomers();
  }

  getCustomers() {
    return this.customerService.getCustomers()
               .subscribe(customers => {
                  console.log('se ha consultado todos los clientes');
                  this.customers = customers
                 }
                );
 }
}
