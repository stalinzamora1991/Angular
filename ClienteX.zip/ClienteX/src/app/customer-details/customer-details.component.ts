import { Component, OnInit } from '@angular/core';
import { Customer } from '../Modelos/customer';
import { CustomerService } from '../Servicios/customer.service';

import { ActivatedRoute, Params } from '@angular/router';
import { Location } from '@angular/common';

@Component({
  selector: 'app-customer-details',
  templateUrl: './customer-details.component.html',
  styleUrls: ['./customer-details.component.scss']
})
export class CustomerDetailsComponent implements OnInit {

  customer = new Customer() ;
  submitted = false;
  message: string;

  constructor(
    private customerService: CustomerService,
    private route: ActivatedRoute,
    private location: Location
  ) {}

  ngOnInit(): void {
    const id = +this.route.snapshot.paramMap.get('id');
    
  }

  update(): void {
    this.submitted = true;
    
  }

  delete(): void {
    this.submitted = true;
    
  }

  goBack(): void {
    this.location.back();
  }
}
