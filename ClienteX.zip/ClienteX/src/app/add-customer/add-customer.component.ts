import { Component, OnInit } from '@angular/core';
import { Customer } from '../Modelos/customer';
import { CustomerService } from '../Servicios/customer.service';
import { Location } from '@angular/common';

@Component({
  selector: 'app-add-customer',
  templateUrl: './add-customer.component.html',
  styleUrls: ['./add-customer.component.scss']
})
export class AddCustomerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
