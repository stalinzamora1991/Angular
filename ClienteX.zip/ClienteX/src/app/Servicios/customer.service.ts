import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Customer } from '../Modelos/customer';


@Injectable({
  providedIn: 'root'
})
export class CustomerService {
  private customersUrl = 'http://localhost:8080/api/customers';  // URL to web api
  constructor( 
    private http: HttpClient
  ) { }
  getCustomers(): Observable<Customer[]>{
    return this.http.get<Customer[]>(this.customersUrl)  
  }

  getCustomer(id: number){
  }

  addCustomer(){
  }

  deleteCustomer() {    
  }

  updateCustomer(){
  }
}
