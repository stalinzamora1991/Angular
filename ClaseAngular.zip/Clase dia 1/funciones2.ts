var x=1;
var y=2;

if (x){
let x=3
console.log("valor de x: " + x);
console.log("valor de y: " + y);
}
console.log("valor de x: " +x);
console.log("valor de y: " +y);

