var Var2 = {
    nombre: "Stalin",
    apellido: "Zamora"
};
console.log(Var2);
var ClienteX = /** @class */ (function () {
    function ClienteX(nombres, apellidos, identificacion) {
        this.nombre = nombres;
        this.apellido = apellidos;
        this.identificacion = identificacion;
    }
    return ClienteX;
}());
var nuevoCliente = new ClienteX("Santiago", "Zamora", "0934758792");
console.log(nuevoCliente);
