function suma(a, b) {
    return a + b;
}
var x = suma(1, 2);
console.log(x);
function mostrartexto(texto) {
    if (texto) {
        console.log("si llegò cadena");
    }
    else {
        console.log("No llegó cadena");
    }
}
mostrartexto("Stalin Zamora");
function mostrartexto2(texto) {
    if (texto === void 0) { texto = "Hola mundo"; }
    console.log(texto);
}
mostrartexto2();
