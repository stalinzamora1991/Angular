setTimeout(function mostrar(){
    console.log("NO se utiliza funcion");
},2);

setTimeout(()=>console.log("Se utiliza funcion"));



var resultado = function MostrarSuma(a: number, b:number){
    return a+b;
}
console.log(resultado(4,6));

var resultado2 = (a: number, b:number) => a+b;
console.log(resultado2(4,6));



var mostrarItem = function MostrarDatos(id: number){
    return {id : id,
            nombre: "Santiago"}
}
console.log(mostrarItem(4));

var mostrarItem2 = (id: number) => ({id : id,nombre: "Santiago"})
console.log(mostrarItem2(3));