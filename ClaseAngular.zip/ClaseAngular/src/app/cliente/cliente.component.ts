import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';


@Component({
  selector: 'app-cliente',
  templateUrl: './cliente.component.html',
  styleUrls: ['./cliente.component.css']
})
export class ClienteComponent implements OnInit {
@Input() contenido2: string;
@Output() mensajeLeido= new EventEmitter();

  constructor() { }

  ngOnInit() {
  }

confirmar(){
  this.mensajeLeido.emit(false);
}
mostrarTexto1(){
  window.alert('metodo del component hijo');
}

}
