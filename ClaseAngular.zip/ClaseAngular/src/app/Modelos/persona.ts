export class Persona {
nombre: string;
apellido: string;
edad: number;
}
