export interface Persona2 {
}
