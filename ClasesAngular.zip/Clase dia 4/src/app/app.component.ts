import { Component, OnInit } from '@angular/core';
import { Persona } from './interfaces/Persona';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  public readonly estilos_cliente={
    color: 'green',
    fontSize: '30px'
  };
  nombre: string= null;
  personas: Persona[] = [
    {nombre:'stalin', apellido:'Zamora',tipo:'cliente'},
    {nombre:'Santiago', apellido:'Abad',tipo:'vendedor'},
  ]
}
