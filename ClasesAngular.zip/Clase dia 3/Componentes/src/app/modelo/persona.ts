export interface Persona {
    nombres: string,
    apellidos: string,
    correoElectronico?: string;
}
