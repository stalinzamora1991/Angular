import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-mensaje',
  templateUrl: './mensaje.component.html',
  styleUrls: ['./mensaje.component.css']
})
export class MensajeComponent implements OnInit {
  @Input() contenido: string;
  @Output() mensajeLeido = new EventEmitter();
  constructor()  { }
  
  confirmar(){
    this.mensajeLeido.emit(true);
  }
  ngOnInit() {
  }

}
