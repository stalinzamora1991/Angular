import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-conteo',
  templateUrl: './conteo.component.html',
  styleUrls: ['./conteo.component.scss']
})
export class ConteoComponent implements OnInit {
  valor: number;
  @Input() valor_ini: number;
  constructor() { }
  suma() {
    this.valor ++;
  }

  resta() {
    this.valor --;
  }

  inicio() {
    this.valor = 0;
  }

  ngOnInit() {
    this.valor = this.valor_ini;
  }

}
