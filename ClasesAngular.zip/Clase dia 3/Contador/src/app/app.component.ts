import { ConteoComponent } from './conteo/conteo.component';
import { Component, ViewChild  } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'contador';
  inicial = 50;
  @ViewChild(ConteoComponent) conteoComponent: ConteoComponent;

  validaIncre() {
    this.conteoComponent.suma();
  }
  validaDecre() {
    this.conteoComponent.resta();
  }
  validaCero() {
    this.conteoComponent.inicio();
  }
}
