var numero = [];
var numero2 = [];
numero.push(1, 2, 3, 4);
console.log(numero);
var nombres = ["stalin", "santiago", "zamora"];
var tupla1 = ["santiago", 28, 34];
//map
var cuadrados = numero.map(function (numero) { return Math.pow(numero, 2); });
console.log(cuadrados);
//filter
var numeros = [1, 2, 3, 4, 5, 6, 7, 8];
var filtro = numeros.filter(function (num) { return num > 4 && num < 8; });
console.log(filtro);
//reduce
var suma = [1, 2, 3, 4].reduce(function (a, b) { return a + b; });
console.log(suma);
//foreach
var num = [7, 8, 9, 10];
num.forEach(function (value) {
    console.log(value);
});
//find 
var array1 = [5, 12, 7, 130, 44];
var found = array1.find(function (element) {
    return element > 6 && element < 8;
});
console.log(found);
