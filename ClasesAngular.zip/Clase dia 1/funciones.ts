function suma(a: number, b: number): number {
    return a + b;
}
var x = suma(1,2);
console.log(x);

function mostrartexto(texto?: string){
    if (texto){
        console.log("si llegò cadena");
    }   
    else{
        console.log("No llegó cadena");
    }
   }
mostrartexto("Stalin Zamora");   

function mostrartexto2(texto: string="Hola mundo"){
            console.log(texto);
}
mostrartexto2();  
