class Persona{
    public nombre;
    public apellido;

    constructor(var1: string, var2: string){
        this.nombre = var1;
        this.apellido = var2;
    }
    getNombre(){
        return this.nombre;
    }
    setNombre(nombre1: string){
        this.nombre= nombre1;
    }
}

var persona1 = new Persona("Santiago","Zamora");
console.log(persona1);
persona1.setNombre("Stalin");
console.log(persona1.nombre);
