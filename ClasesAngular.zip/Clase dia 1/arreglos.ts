var numero: number[] = [];
var numero2: Array<number> = [];
numero.push(1,2,3,4);
console.log(numero);

var nombres: string[] = ["stalin","santiago","zamora"];
var tupla1: [string, number, number] = ["santiago",28,34];

//map
var cuadrados=numero.map((numero) => Math.pow(numero,2));
console.log(cuadrados);

//filter
var numeros = [1,2,3,4,5,6,7,8];
var filtro = numeros.filter( num => num > 4 && num < 8);
console.log(filtro);

//reduce
const suma =[1,2,3,4].reduce((a,b) => a+b);
console.log(suma);

//foreach
var num= [7,8,9,10];
num.forEach(function(value){
    console.log(value);
})

//find 
var array1 = [5, 12, 7, 130, 44];
var found = array1.find(function(element) {
  return element > 6 && element <8;
});
console.log(found);