var Persona = /** @class */ (function () {
    function Persona(var1, var2) {
        this.nombre = var1;
        this.apellido = var2;
    }
    Persona.prototype.getNombre = function () {
        return this.nombre;
    };
    Persona.prototype.setNombre = function (nombre1) {
        this.nombre = nombre1;
    };
    return Persona;
}());
var persona1 = new Persona("Santiago", "Zamora");
console.log(persona1);
persona1.setNombre("Stalin");
console.log(persona1.nombre);
