var x = 1;
var y = 2;
if (x) {
    var x_1 = 3;
    console.log("valor de x: " + x_1);
    console.log("valor de y: " + y);
}
console.log("valor de x: " + x);
console.log("valor de y: " + y);
