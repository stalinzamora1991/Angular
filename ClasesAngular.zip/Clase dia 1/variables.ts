let hora: number;
let hora1: "cadena";
let texto: string = "hola"
let activo: boolean;
let texto2 : string[]= ["A","B"];
let desconocido: any =2;


