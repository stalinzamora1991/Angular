setTimeout(function mostrar() {
    console.log("NO se utiliza funcion");
}, 2);
setTimeout(function () { return console.log("Se utiliza funcion"); });
var resultado = function MostrarSuma(a, b) {
    return a + b;
};
console.log(resultado(4, 6));
var resultado2 = function (a, b) { return a + b; };
console.log(resultado2(4, 6));
var mostrarItem = function MostrarDatos(id) {
    return { id: id,
        nombre: "Santiago" };
};
console.log(mostrarItem(4));
var mostrarItem2 = function (id) { return ({ id: id, nombre: "Santiago" }); };
console.log(mostrarItem2(3));
