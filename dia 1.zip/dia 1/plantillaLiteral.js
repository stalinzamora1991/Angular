function mostrarmensaje(error, segundos) {
    console.log("ocurrió un error: " + error + ". intentelo en: " + segundos + "s");
}
mostrarmensaje("capa8", 2);
function mostrarmensaje2(error, segundos) {
    console.log("ocurri\u00F3 un error:  " + error + "  intentelo en: " + segundos + " s");
}
mostrarmensaje2("sintaxis", 4);
