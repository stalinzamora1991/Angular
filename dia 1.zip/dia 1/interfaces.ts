interface Persona2{
    nombre: string,
    apellido: string
}

var Var2: Persona2 = {
    nombre: "Stalin",
    apellido: "Zamora"
};
console.log(Var2);

class ClienteX implements Persona2 {
    public nombre: string;
    public apellido: string;
    public identificacion: string;

    public constructor(nombres: string, apellidos: string, identificacion: string){
        this.nombre = nombres;
        this.apellido = apellidos;
        this.identificacion= identificacion;
    }
}
let nuevoCliente: ClienteX = new ClienteX ("Santiago","Zamora","0934758792");
console.log(nuevoCliente);