export interface ItemFactura {
  producto: string;
  cantidad: number;
  precioUnitario: number;
}
