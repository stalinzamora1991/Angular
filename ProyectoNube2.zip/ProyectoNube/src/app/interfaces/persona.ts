export interface Persona {
nombre: string;
apellido:string;
}
