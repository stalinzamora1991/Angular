import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-muestra',
  templateUrl: './muestra.component.html',
  styleUrls: ['./muestra.component.css']
})
export class MuestraComponent implements OnInit {
  @Input() contenido1: string;
  @Output() mensajeLeido = new EventEmitter();
  constructor() { }
  confirmar(){
    this.mensajeLeido.emit(true);
  }

  ngOnInit() {
  }

  retornaNombre(){
    window.alert('Clase Angular');
  }
}
