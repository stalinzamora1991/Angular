import { Component, OnInit, ViewChild } from '@angular/core';
import { Persona } from './interfaces/persona';
import { MuestraComponent } from './muestra/muestra.component';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  @ViewChild(MuestraComponent) muestraComponent: MuestraComponent;
  retornaTexto(){
    this.muestraComponent.retornaNombre();
  }
  title = 'proyecto1';
  nombre = 'Santiago';
  dato: string= 'claseAngular';
  valorx = 1.14458786;
persona1: Persona = {
  nombre:'Stalin',
  apellido:'Zamora'
};
 titulomin= 'valor1';
 titulomay= 'VALOR2';
 titulo2 = 'curso angular';
 fecha = Date.now();

obtenerTitulo(){
  return this.title;
}
var1='cerrar';
var2='szamora';
mensaje1="hola mundo"
cambio(){
  this.var1='salir';
}
public personas;
ngOnInit(){
this.personas=[
  {nombres: 'stalin',apellidos:'zamora',tipo:'vendedor'},
  {nombres: 'santiago',apellidos:'abad',tipo:'proveedor'},
  {nombres: 'Luis',apellidos:'Zambrano',tipo:'estudiante'},
];

}
mostrarMensaje(){
  window.alert('mensaje leido');
}
public readonly estilo_vendedor={
  color:'green',
  fontSize:'30px'
}
public readonly color_proveedor='blue';
public readonly color_desconocido='red'

}
