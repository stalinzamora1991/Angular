export interface Personas {
    nombres: string;
    apellidos: string;
}
