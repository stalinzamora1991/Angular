import { Component, ViewChild } from '@angular/core';
import { Personas } from './interfaces/personas';
import { MuestraComponent } from './muestra/muestra.component';
import { Muestra2Component } from './muestra2/muestra2.component';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  valor_ini=10;
  @ViewChild(Muestra2Component) var1: Muestra2Component;

  public sumar1(){
    this.var1.suma();
  }

  public resta1(){
    this.var1.resta();
  }

  public reseteo1(){
    this.var1.reseteo();
  }

  /*@ViewChild(MuestraComponent) muestraComponent : MuestraComponent

mostrar(){
  this.muestraComponent.mostrarTexto();
}

  mensaje1='mensaje de prueba';
  title = 'proyecto1';
  nombres = 'Santiago Zamora';
  titulo= 'Angular 7';
persona: Personas ={
  nombres: 'Santiago',
  apellidos: 'Zamora'
}
textomin='clase angular';
textomay='CLASE ANGULAR';
titulo2 ='las clases de angular';
valor = 3.1416;
fecha = Date.now();
obtenertitulo(){
  return this.title;
}
boton1='Boton Angular 123';
nuevoCorreo='sza';


cambiartexto(){
  this.boton1='Boton salir';
}
mostrarMensaje(a: boolean){
  if (a) {
    window.alert('Mensaje recibido');
  }else{
    window.alert('No se recibió mensaje');
  }
}*/

}
