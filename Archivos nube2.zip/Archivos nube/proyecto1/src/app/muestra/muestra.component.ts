import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-muestra',
  templateUrl: './muestra.component.html',
  styleUrls: ['./muestra.component.css']
})
export class MuestraComponent implements OnInit {
@Input() contenido: string;
@Output() mensajeLeido = new EventEmitter();
  constructor() { }

  ngOnInit() {
  }
confirmar(){
  this.mensajeLeido.emit(true);
}
mostrarTexto(){
  window.alert('mensaje desde componente hijo');
}
}
