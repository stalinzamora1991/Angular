import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-muestra2',
  templateUrl: './muestra2.component.html',
  styleUrls: ['./muestra2.component.css']
})
export class Muestra2Component implements OnInit {
@Input() numero: number;

  constructor() { }


public suma(){
  this.numero = this.numero +1;
}

public resta(){
  this.numero = this.numero -1;
}

public reseteo(){
  this.numero = 0;
}


  ngOnInit() {
  }

}
