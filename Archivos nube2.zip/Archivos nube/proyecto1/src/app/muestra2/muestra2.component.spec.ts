import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Muestra2Component } from './muestra2.component';

describe('Muestra2Component', () => {
  let component: Muestra2Component;
  let fixture: ComponentFixture<Muestra2Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Muestra2Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Muestra2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
