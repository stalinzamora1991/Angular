setTimeout(function(){
    console.log('Saludos Curso Angular');
},0);

setTimeout(() => 
    console.log('Saludos Curso Angular 2'
),0);

var nombre1= function getNombre(){
    return 'Santiago Zamora';
}
console.log(nombre1());

var nombre2= () => 'Santiago Zamora';
console.log(nombre2());

var resultado = function sumar(valor1: number, valor2: number){
    return valor1+valor2;
}
var resultado = (valor1: number, valor2: number) => (valor1+valor2);
console.log(resultado(2,5));