var Personas = /** @class */ (function () {
    function Personas(var1, var2) {
        this.nombre = var1;
        this.apellido = var2;
    }
    Personas.prototype.getNombre = function () {
        return this.nombre;
    };
    Personas.prototype.setNombre = function (nombrex) {
        this.nombre = nombrex;
    };
    return Personas;
}());
var persona1 = new Personas('Santiago', 'Zamora');
console.log(persona1.nombre);
persona1.setNombre('Stalin');
console.log(persona1.nombre);
