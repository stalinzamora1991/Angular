interface Persona {
    nombre: string,
    apellido: string
}
var per1: Persona={
    nombre:'Santiago',
    apellido:'Zamora'
}
console.log(per1);
class Cliente implements Persona{
    public nombre: string;
    public apellido: string;
    public identificacion: string;

    public constructor(nom:string, ape: string, iden: string){
        this.nombre=nom;
        this.apellido= ape;
        this.identificacion=iden;
    }
}
var nuevoCliente: Cliente = new Cliente('Stalin','Zamora','09304876544');
console.log(nuevoCliente);